<div id="nav">

	<a href="index.php">Home</a>
	<a href="Settings.php">Settings</a>
	<a href="LED.php">LED</a>
	<a href="Other.php">Other</a>
    <a href="test.php">test</a>
    <a href="Admin.php">Admin</a>
</div> <!-- end #nav -->
