<div id="sidebar">

<h3>Navigation</h3>
	<li><a href="index.php">Home</a></li>
	<li><a href="Settings.php">Settings</a></li>
	<li><a href="LED.php">LED</a></li>
	<li><a href="Other.php">Other</a></li>
	<li><a href="test.php">Test</a></li>
	<li><a href="Admin.php">Admin</a></li>

<h3>Pumps</h3>
	<li><a href="index.php">Link Here</a></li>
	<li><a href="index.php">Link Here</a></li>
	<li><a href="index.php">Link Here</a></li>
	<li><a href="index.php">Link Here</a></li>
	<li><a href="index.php">Link Here</a></li>

<h3>LEDs</h3>
	<li><a href="index.php">Link Here</a></li>
	<li><a href="index.php">Link Here</a></li>
	<li><a href="index.php">Link Here</a></li>
	<li><a href="index.php">Link Here</a></li>
	<li><a href="index.php">Link Here</a></li>

</div> <!-- end #sidebar -->
