<div id="footer">
	<p>Copyright &copy 2014 <a href="#">REEFPI</a></p>
</div> <!-- end #footer -->
