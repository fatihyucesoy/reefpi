<div id="header">

	<!--<h2>REEFPI Web Interface</h2>-->
	<div class="header_img"><img src="Images/logo.png" alt="myPic" /></div>
</div> <!-- end #header -->
